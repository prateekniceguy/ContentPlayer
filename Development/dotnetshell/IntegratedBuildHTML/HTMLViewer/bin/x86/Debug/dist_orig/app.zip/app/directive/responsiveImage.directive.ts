import { Component ,Directive, OnInit , ElementRef, HostListener, Input, Output , NgZone, Renderer, EventEmitter} from '@angular/core';

@Directive({
  selector: '[responsiveImg]',

})
export class ResponsiveImageDirective {
@Input('responsiveImg') option: any;
@Output() srcChange = new EventEmitter<string>();

constructor(private el: ElementRef, private zone: NgZone, private renderer:Renderer) {
	
  }

common(){
	console.log("in directive:",this.option);
	console.log("nativeElement oh ", this.el.nativeElement.outerHTML); 
	console.log("nativeElement tc ", this.el.nativeElement); 
	console.log("nativeElement tc ", this.el); 
	if(window.screen.width > 0 && window.screen.width < 1024) {
				   // var source=this.option.imgsrc;
				   var source=this.option;
				   // var extsource=this.option.imgsrc;
				   var extsource=this.option;
				   var ext= extsource.slice(-4);
				   var str1=source.slice(0, -7) + '-1s' + ext;
				   console.log("str1 1", str1);
				   this.srcChange.emit(str1);
				   // this.option.imgsrc=str1;
				   /*this.zone.run(() => {
					   this.el.nativeElement.src = str1;
				   this.renderer.setElementAttribute(this.el.nativeElement, "src", str1);
				   this.renderer.setElementProperty(this.el.nativeElement, "src", str1);
				   console.log("changed src ", this.el.nativeElement.getAttribute('src'));
				   console.log("changed nativeElement tc ", this.el.nativeElement);
					this.el.nativeElement.style.backgroundColor = 'yellow';				   
				    });*/
	} else if(window.screen.width >= 1024 && window.screen.width < 1525) {
				   var source=this.option;
				   // var source=this.option.imgsrc;
				   // var extsource=this.option.imgsrc;
				   var extsource=this.option;
				   var ext= extsource.slice(-4);
				   var str1=source.slice(0, -7) + '-2s' + ext;
				   console.log("str1 2", str1);
				   this.srcChange.emit(str1);
				   // this.option.imgsrc=str1;
				   /* this.zone.run(() => {
						this.el.nativeElement.src = str1;
				   this.renderer.setElementAttribute(this.el.nativeElement, "src", str1);
				   this.renderer.setElementProperty(this.el.nativeElement, "src", str1);
				   console.log("changed src ", this.el.nativeElement.getAttribute('src'));
				   console.log("changed nativeElement tc ", this.el.nativeElement); 
				   this.el.nativeElement.style.backgroundColor = 'yellow';	
				    });*/
	} else {
				   var source=this.option;
				   // var source=this.option.imgsrc;
				   var extsource=this.option;
				   // var extsource=this.option.imgsrc;
				   var ext= extsource.slice(-4);
				   var str1=source.slice(0, -7) + '-3s'+ ext;
				   console.log("str1 3", str1);
				   this.srcChange.emit(str1);
				   // this.option.imgsrc=str1;
				   /*this.zone.run(() => {
					   this.el.nativeElement.src = str1;
				   this.renderer.setElementAttribute(this.el.nativeElement, "src", str1);
				   this.renderer.setElementProperty(this.el.nativeElement, "src", str1);
				   console.log("changed src ", this.el.nativeElement.getAttribute('src'));
				   console.log("changed nativeElement tc ", this.el.nativeElement); 
				   this.el.nativeElement.style.backgroundColor = 'yellow';	
				    });*/
	}
	  var abc = this;
			 
			  const mql: MediaQueryList = window.matchMedia('(min-width: 0px) and  (max-width: 1023px) ');
			  const mql1: MediaQueryList = window.matchMedia('(min-width: 1024px) and (max-width: 1524px) ');
			  const mql2: MediaQueryList = window.matchMedia('(min-width: 1525px) and (max-width: 1920px)');
				
			   mql.addListener((mql1: MediaQueryList) => {
				//this.zone.run(() => {
					if(window.screen.width>0 && window.screen.width<=1023 ){
		
				   var source=abc.option;
				   var extsource=abc.option;
				   var ext= extsource.slice(-4);
				   var str1=source.slice(0, -7) + '-1s' + ext;
				   console.log("mq str1", str1);
				   // abc.option=str1;
				   console.log("srcChange", abc.srcChange);
				   abc.srcChange.emit(str1);
					}
			//});

		  });

			  mql1.addListener((mql1: MediaQueryList) => {
				//this.zone.run(() => {
				if(window.screen.width>=1024 && window.screen.width<=1524){
				   //console.log("changing", abc.option.imgsrc);
				   var source=abc.option;
				   var extsource=abc.option;
				   var ext= extsource.slice(-4);
				   var str1=source.slice(0, -7) + '-2s' + ext;
				   console.log("mq str1", str1);
				   //abc.option=str1;
				   console.log("srcChange", abc.srcChange);
				   abc.srcChange.emit(str1);
					}
			//});

		  });
				mql2.addListener((mql2: MediaQueryList) => {
				//this.zone.run(() => {
				   if(window.screen.width>=1525){
				   var source=abc.option;
				   var extsource=abc.option;
				   var ext= extsource.slice(-4);
				   var str1=source.slice(0, -7) + '-3s'+ ext;
				   console.log("mq str1", str1);
				   //abc.option.imgsrc=str1;
				   console.log("srcChange", abc.srcChange);
				   abc.srcChange.emit(str1);
				   }
				//});
			  });
}  



	  
	  ngOnChanges (){
        this.common();

     }

	  
	
    }




/**
  @HostListener('window:resize', ['$event'])  onResize(event) {

this.foo( event )
  }



 this.resolutions =["800x600","1024x768","1920x1080"];
public foo( event:any ){


  console.log('dadasdsadasdsad----->',event.target.innerWidth )

  var abc = this;
   var resolution;
   var windowWidth = event.target.innerWidth;

   //if valid URL
   this.resolutions.forEach(function(item){


    if(abc.option.imgsrc.indexOf(item)>-1){
         resolution =  item;
       }
    });

  //then replace according to width
  if(resolution){

    if(windowWidth<=800) {

    this.option.imgsrc = this.option.imgsrc.replace(resolution, this.resolutions[0]);

    }
    else if(800<windowWidth && windowWidth<=1024){

    this.option.imgsrc = this.option.imgsrc.replace(resolution, this.resolutions[1]);
    }
    else if(windowWidth > 1024){
    this.option.imgsrc = this.option.imgsrc.replace(resolution, this.resolutions[2]);
    }

    console.log('changed to', this.option.imgsrc);
  }


}*/
